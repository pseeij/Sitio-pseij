=== Atuxa ===
Contributors: DesertThemes
Requires at least: 4.7
Tested up to: 6.7
Requires PHP: 5.6
Stable tag: 1.0.33
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Tags: one-column, two-columns ,right-sidebar, flexible-header, custom-background, custom-header, custom-menu, editor-style, featured-images, footer-widgets, post-formats, theme-options, threaded-comments, translation-ready, full-width-template, custom-logo, blog, e-commerce, portfolio


== Description ==

Atuxa is lightweight, highly extendable and multi-purpose WordPress Theme. It will enable you to create almost any type of website with a beautiful & professional design. Atuxa supports popular WordPress plugins such as Elementor, WPML, Polylang, Yoast SEO, WooCommerce, Contact Form 7, Jetpack, and much more. Atuxa Pro demo https://preview.desertthemes.com/pro/atuxa/


== Installation ==
	
1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Atuxa in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.


== Copyright ==

Atuxa WordPress Theme, Copyright 2024 , Desert Themes
Atuxa is distributed under the terms of the GNU GPL

Atua WordPress Theme, Desert Themes. Atua WordPress Theme is distributed under the terms of the GNU GPL



== Credits ==

* Underscores - (C) 2012-2017 Automattic, Inc. - http://underscores.me/
License: GPLv2 or later (https://www.gnu.org/licenses/gpl-2.0.html) 

* Font Awesome 6.3.0 
Licenses - Font: SIL OFL 1.1, CSS: MIT License(http://fontawesome.io/license)
Source: https://github.com/FortAwesome/Font-Awesome

* Owl Carousel 2.3.4 - by @David Deutsch
Licenses - MIT License(https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE)
Source: https://github.com/OwlCarousel2

* WOW - by Thomas Grainger
Licenses - MIT License (https://github.com/graingert/WOW/blob/master/LICENSE)
Source: https://wowjs.uk/

* Parallax 
Licenses - MIT License (https://github.com/wagerfield/parallax/blob/master/LICENSE)
Source: https://github.com/wagerfield/parallax

* Animate Css by @Daniel Eden - http://daneden.me/animate
Licenses - MIT License(https://github.com/daneden/animate.css/blob/master/LICENSE)
Source: https://github.com/daneden/animate.css

* Customizer Controls 
Licenses - MIT license  (https://github.com/Codeinwp/customizer-controls/blob/master/LICENSE)
Source: https://github.com/Codeinwp/customizer-controls

* WP Bootstrap Navwalker
Licenses - GNU GENERAL PUBLIC LICENSE (https://github.com/wp-bootstrap/wp-bootstrap-navwalker/blob/master/LICENSE.txt)
Source: https://github.com/wp-bootstrap/wp-bootstrap-navwalker

* Sainitization
Licenses - GNU General Public License (https://github.com/WPTRT/code-examples/blob/master/LICENSE)
Source: https://github.com/WPTRT/code-examples

* Screenshot Banner Image - https://pxhere.com/en/photo/836370
License: CC0 Public Domain

* Screenshot Information Image - https://pxhere.com/en/photo/1453707 , https://pxhere.com/en/photo/1444157 , https://pxhere.com/en/photo/1432441
License: Creative Commons Zero

* Page Title Image - https://pxhere.com/en/photo/1258666
License: Creative Commons Zero

== Changelog ==

@version 1.0.33
* Style improvements - WooCommerce Block Cart Checkout Button

@version 1.0.32
* Style improvements - WooCommerce Block Cart

@version 1.0.31
* Tested - By WordPress 6.7.1

@version 1.0.30
* Tested - By WordPress 6.7

@version 1.0.29
* Style improvements - WooCommerce Block Cart

@version 1.0.28
* Style improvements - WooCommerce Block Product

@version 1.0.27
* Style improvements - WooCommerce Block Cart

@version 1.0.26
* Style improvements - WooCommerce Block Cart Button

@version 1.0.25
* Style improvements - WooCommerce Block Cart Product Price

@version 1.0.24
* Style improvements - WooCommerce Block Cart Product Description

@version 1.0.23
* Style improvements - WooCommerce Block Cart Product Title

@version 1.0.22
* Style improvements - WooCommerce Handpicked Product Button

@version 1.0.21
* Tested - By WordPress 6.6.2

@version 1.0.20
* Style improvements - WooCommerce Handpicked Product Button Hover & Focus

@version 1.0.19
* Style improvements - WooCommerce Handpicked Product Button

@version 1.0.18
* Style improvements - WooCommerce Featured Product Button

@version 1.0.17
* Style improvements - WooCommerce Featured Product Price

@version 1.0.16
* Style improvements - WooCommerce Store Breadcrumbs

@version 1.0.15
* Style improvements - WooCommerce Featured Category Button

@version 1.0.14
* Style improvements - WooCommerce Checkout Page Summary

@version 1.0.13
* Tested - By WordPress 6.6.1

@version 1.0.12
* Style improvements - WooCommerce Checkout Page Button     

@version 1.0.11
* Style improvements - WooCommerce Cart Page Product Badge    

@version 1.0.10
* Style improvements - WooCommerce Cart Page

@version 1.0.9
* Tested - By WordPress 6.5.5

@version 1.0.8
* Style Updated - Block Post Author & Date

@version 1.0.7
* Style improvements - WooCommerce Cart Page 

@version 1.0.6
* Style improvements - WooCommerce Cart Page 

@version 1.0.5
* Style improvements - WooCommerce Cart Page Product Price

@version 1.0.4
* Tested - By WordPress 6.5.2

@version 1.0.3
* Tested - By WordPress 6.5

@version 1.0.2
* Style improvements - WooCommerce Cart Page Product Title

@version 1.0.1
* Fixed - Block Calendar Head Color Issue

@version 1.0
* Style improvements - Product Button Hover & Focus

@version 0.9
* Style improvements - Block Calendar Caption

@version 0.8
* Style improvements - Product Title

@version 0.7
* Style improvements - Block Table

@version 0.6
* Style improvements - Block Table

@version 0.5
* Style improvements - Product Price

@version 0.4
* Style improvements - Product Button

@version 0.3
* Style improvements - Product Button

@version 0.2
* Added Theme URI
* Added Upsale Link in Customizer

@version 0.1
* Initial release